const { ccclass, property } = cc._decorator;

@ccclass
export default class ItemPlacer extends cc.Component {
    @property({ type: [cc.Prefab] })
    public iconPrefabs: cc.Prefab[] = [];

    @property({ type: [cc.Prefab] })
    public actualPrefabs: cc.Prefab[] = [];

    @property(cc.Node)
    public mapNode: cc.Node = null;

    @property(cc.Node)
    public cursorLayer: cc.Node = null;

    private cursorItem: cc.Node = null;
    private selectedType: string = null;
    private currentPrefab: cc.Prefab = null;

    onLoad() {
        this.cursorLayer.on(cc.Node.EventType.MOUSE_MOVE, this.onMouseMove, this);
        this.cursorLayer.on(cc.Node.EventType.MOUSE_DOWN, this.onMouseDown, this);
    }

    onDestroy() {
        this.cursorLayer.off(cc.Node.EventType.MOUSE_MOVE, this.onMouseMove, this);
        this.cursorLayer.off(cc.Node.EventType.MOUSE_DOWN, this.onMouseDown, this);
    }

    public setSelectedType(type: string) {
        this.selectedType = type;

        if (this.cursorItem) this.cursorItem.destroy();

        const iconPrefab = this.iconPrefabs.find(p => p.name.toLowerCase().includes(type));
        const actualPrefab = this.actualPrefabs.find(p => p.name.toLowerCase().includes(type));

        if (!iconPrefab || !actualPrefab) {
            console.warn("❗ 找不到對應 icon 或 prefab:", type);
            return;
        }

        this.currentPrefab = actualPrefab;

        this.cursorItem = cc.instantiate(iconPrefab);
        this.cursorItem.opacity = 180;
        this.cursorItem.parent = this.cursorLayer;
        this.cursorItem.zIndex = 999;
    }

    onMouseMove(event: cc.Event.EventMouse) {
        if (!this.cursorItem) return;
        const pos = this.cursorLayer.convertToNodeSpaceAR(event.getLocation());
        this.cursorItem.setPosition(pos);
    }

    onMouseDown(event: cc.Event.EventMouse) {
        if (!this.selectedType || !this.cursorItem || !this.currentPrefab) return;

        const pos = this.mapNode.convertToNodeSpaceAR(event.getLocation());

        const newItem = cc.instantiate(this.currentPrefab);
        newItem.setPosition(pos);
        this.mapNode.addChild(newItem);

        console.log(`✅ 已放置 ${this.selectedType} 於 `, pos);
    }
}
